#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "This builds a standalone QueryDraft app -- a single file you can double-click from now on."
echo "This step only needs to run once, and needs Python + internet access."
echo ""

python3 -m venv build_venv
./build_venv/bin/pip install --quiet -r requirements.txt pyinstaller

echo ""
echo "Building QueryDraft (this can take a minute)..."
./build_venv/bin/pyinstaller --onefile --name QueryDraft --add-data "frontend:frontend" app.py

echo ""
echo "Done. Your app is at: dist/QueryDraft"
echo "Move or copy that one file anywhere you like."
echo "From now on, just double-click it (Mac may ask you to allow it once"
echo "in System Settings > Privacy & Security). You don't need this folder,"
echo "Python, or anything else after that."
