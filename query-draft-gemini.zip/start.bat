@echo off
cd /d "%~dp0"

if not exist venv (
  echo Setting up (first run only, this takes a minute)...
  python -m venv venv
  venv\Scripts\pip install --quiet -r requirements.txt
)

venv\Scripts\python app.py
pause
